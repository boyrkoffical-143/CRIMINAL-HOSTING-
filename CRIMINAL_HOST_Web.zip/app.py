#!/usr/bin/env python3
"""
Telegram Bot Hosting Panel — Web Version
Upload, run, stop and manage Telegram bots from the browser.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import zipfile
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Dict, List, Optional

from flask import (
    Flask,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

# ── Paths ──────────────────────────────────────────────────────────
BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "data"
BOTS_DIR = BASE / "bots"
UPLOADS_DIR = BASE / "uploads"
for d in (DATA_DIR, BOTS_DIR, UPLOADS_DIR):
    d.mkdir(parents=True, exist_ok=True)

DB_FILE = DATA_DIR / "db.json"
USERS_FILE = DATA_DIR / "users.json"

# ── Config (override with env) ─────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "admin123")  # change after first login
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8080"))
MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "25"))
OWNER_UNLIMITED = True

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

# ── In-memory process table ────────────────────────────────────────
RUNNING: Dict[str, Dict[str, Any]] = {}  # bot_id -> {proc, log, started, manual_stop}
_LOCK = threading.Lock()
LOG_RING = 400


# ═══════════════════════════════════════════════════════════════════
#  DATABASE HELPERS
# ═══════════════════════════════════════════════════════════════════

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def db_load() -> Dict[str, Any]:
    return _load_json(DB_FILE, {"bots": {}, "settings": {}})


def db_save(data: Dict[str, Any]) -> None:
    _save_json(DB_FILE, data)


def users_load() -> Dict[str, Any]:
    data = _load_json(USERS_FILE, {"users": {}})
    # bootstrap admin
    if ADMIN_USER not in data["users"]:
        data["users"][ADMIN_USER] = {
            "password": generate_password_hash(ADMIN_PASS),
            "role": "admin",
            "plan": "unlimited",
            "max_bots": 9999,
            "created": _now(),
            "banned": False,
        }
        _save_json(USERS_FILE, data)
    return data


def users_save(data: Dict[str, Any]) -> None:
    _save_json(USERS_FILE, data)


def get_user(username: str) -> Optional[Dict[str, Any]]:
    return users_load()["users"].get(username)


def user_bot_count(username: str) -> int:
    db = db_load()
    return sum(1 for b in db["bots"].values() if b.get("owner") == username)


def user_max_bots(username: str) -> int:
    u = get_user(username)
    if not u:
        return 0
    if u.get("role") == "admin" or u.get("plan") == "unlimited":
        return 9999
    return int(u.get("max_bots", 2))


# ═══════════════════════════════════════════════════════════════════
#  AUTH
# ═══════════════════════════════════════════════════════════════════

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("login"))
        u = get_user(session["user"])
        if not u or u.get("banned"):
            session.clear()
            flash("Account banned or not found.", "error")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapped


def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("login"))
        u = get_user(session["user"])
        if not u or u.get("role") != "admin":
            flash("Admin only.", "error")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapped


# ═══════════════════════════════════════════════════════════════════
#  BOT PROCESS MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

COMMON_PIP_MAP = {
    "telebot": "pyTelegramBotAPI",
    "PIL": "Pillow",
    "cv2": "opencv-python",
    "sklearn": "scikit-learn",
    "bs4": "beautifulsoup4",
    "yaml": "PyYAML",
    "dotenv": "python-dotenv",
    "Crypto": "pycryptodome",
    "discord": "discord.py",
    "github": "PyGithub",
}


def _scan_imports(bot_dir: Path) -> List[str]:
    mods: set = set()
    for py in bot_dir.rglob("*.py"):
        if ".deps" in py.parts or "__pycache__" in py.parts:
            continue
        try:
            src = py.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for m in re.findall(r"^\s*(?:import|from)\s+([a-zA-Z_][\w]*)", src, re.M):
            if m not in sys.stdlib_module_names and m not in ("__future__",):
                mods.add(m)
    return sorted(mods)


def install_deps(bot_dir: Path, log: List[str]) -> None:
    deps = bot_dir / ".deps"
    deps.mkdir(exist_ok=True)
    env = {**os.environ, "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PIP_NO_INPUT": "1"}
    flags = ["--upgrade", "--no-input", "--no-warn-script-location", "--disable-pip-version-check"]

    req = bot_dir / "requirements.txt"
    if req.exists():
        log.append("── pip install -r requirements.txt ──")
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--target", str(deps), *flags, "-r", str(req)],
            cwd=str(bot_dir), capture_output=True, text=True, timeout=600, env=env,
        )
        log.extend((r.stdout or "").splitlines()[-12:])
        log.extend((r.stderr or "").splitlines()[-8:])
        log.append(f"[ok] requirements rc={r.returncode}")

    try:
        modules = _scan_imports(bot_dir)
        pkgs = sorted({COMMON_PIP_MAP.get(m, m) for m in modules})
        # skip already satisfied roughly
        if pkgs:
            log.append(f"── auto-install: {', '.join(pkgs)} ──")
            r2 = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--target", str(deps), *flags, *pkgs],
                cwd=str(bot_dir), capture_output=True, text=True, timeout=600, env=env,
            )
            log.append(f"[ok] auto-install rc={r2.returncode}")
            # persist
            existing = set()
            if req.exists():
                for ln in req.read_text(encoding="utf-8", errors="ignore").splitlines():
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        existing.add(ln.lower().split("==")[0].strip())
            to_add = [p for p in pkgs if p.lower() not in existing]
            if to_add:
                with req.open("a", encoding="utf-8") as fh:
                    fh.write("\n# auto-detected\n")
                    for p in to_add:
                        fh.write(p + "\n")
    except Exception as e:
        log.append(f"[warn] scan: {e}")


def _find_entry(bot_dir: Path) -> Optional[Path]:
    for name in ("main.py", "bot.py", "app.py", "run.py", "__main__.py"):
        p = bot_dir / name
        if p.is_file():
            return p
    pys = [p for p in bot_dir.glob("*.py") if p.name != "requirements.txt"]
    return pys[0] if len(pys) == 1 else None


def _drain(bot_id: str, proc: subprocess.Popen, log: List[str], bot_dir: Path) -> None:
    try:
        if proc.stdout:
            for line in iter(proc.stdout.readline, b""):
                try:
                    txt = line.decode("utf-8", "replace").rstrip()
                except Exception:
                    txt = repr(line)
                log.append(txt)
                if len(log) > LOG_RING:
                    del log[: len(log) - LOG_RING]
        rc = proc.wait()
        log.append(f"── exited rc={rc} ──")

        info = RUNNING.get(bot_id)
        was_manual = not info or info.get("manual_stop")
        db = db_load()
        b = db["bots"].get(bot_id)
        if b:
            b["last_exit_code"] = rc
            b["last_exit_at"] = _now()
            b["last_error"] = "\n".join(log[-10:])[:1200]
            if rc not in (0, None) and not was_manual:
                b["status"] = "crashed"
            else:
                b["status"] = "stopped"
            db_save(db)

        # Auto-fix missing module + restart
        if not was_manual and rc not in (0, None):
            blob = "\n".join(log[-40:])
            m = re.search(r"ModuleNotFoundError:\s*No module named ['\"]([^'\"]+)['\"]", blob)
            if not m:
                m = re.search(r"ImportError:.*['\"]([A-Za-z0-9_\.]+)['\"]", blob)
            if m:
                mod = m.group(1).split(".")[0]
                pkg = COMMON_PIP_MAP.get(mod, mod)
                log.append(f"[auto-fix] installing {pkg}")
                deps = bot_dir / ".deps"
                deps.mkdir(exist_ok=True)
                env = {**os.environ, "PIP_DISABLE_PIP_VERSION_CHECK": "1"}
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--target", str(deps),
                     "--upgrade", "--no-input", pkg],
                    cwd=str(bot_dir), capture_output=True, timeout=300, env=env,
                )
                time.sleep(2)
                b2 = db_load()["bots"].get(bot_id)
                if b2 and b2.get("status") != "stopped":
                    start_bot(bot_id, auto=True)
                    return

            # plan-based auto restart
            if b and b.get("auto_restart"):
                log.append("[auto-restart] in 3s…")
                time.sleep(3)
                b2 = db_load()["bots"].get(bot_id)
                if b2 and b2.get("status") != "stopped":
                    start_bot(bot_id, auto=True)
    except Exception as e:
        log.append(f"[drain error] {e}")
    finally:
        with _LOCK:
            if bot_id in RUNNING and RUNNING[bot_id].get("proc") is proc:
                RUNNING.pop(bot_id, None)


def start_bot(bot_id: str, auto: bool = False) -> Dict[str, Any]:
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b:
        return {"ok": False, "error": "Bot not found"}

    with _LOCK:
        if bot_id in RUNNING and RUNNING[bot_id]["proc"].poll() is None:
            return {"ok": False, "error": "Already running"}

    bot_dir = Path(b["dir"])
    if not bot_dir.exists():
        return {"ok": False, "error": "Bot directory missing"}

    entry = _find_entry(bot_dir)
    if not entry:
        return {"ok": False, "error": "No main.py / bot.py found"}

    log: List[str] = []
    try:
        install_deps(bot_dir, log)
    except Exception as e:
        log.append(f"[deps warn] {e}")

    deps = bot_dir / ".deps"
    env = {**os.environ}
    # strip secrets from child
    for k in list(env):
        if any(x in k.upper() for x in ("TOKEN", "SECRET", "PASSWORD", "API_KEY")):
            if k not in (b.get("env") or {}):
                env.pop(k, None)
    # user env vars
    for k, v in (b.get("env") or {}).items():
        env[str(k)] = str(v)
    # PYTHONPATH so .deps is used
    pp = str(deps)
    if env.get("PYTHONPATH"):
        pp = pp + os.pathsep + env["PYTHONPATH"]
    env["PYTHONPATH"] = pp
    env["PYTHONUNBUFFERED"] = "1"

    try:
        proc = subprocess.Popen(
            [sys.executable, "-u", str(entry)],
            cwd=str(bot_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            start_new_session=True,
        )
    except Exception as e:
        return {"ok": False, "error": str(e)}

    with _LOCK:
        RUNNING[bot_id] = {
            "proc": proc,
            "log": log,
            "started": time.time(),
            "manual_stop": False,
            "pid": proc.pid,
        }

    threading.Thread(target=_drain, args=(bot_id, proc, log, bot_dir), daemon=True).start()

    b["status"] = "running"
    b["last_started"] = _now()
    b["last_error"] = ""
    b["last_exit_code"] = None
    b["pid"] = proc.pid
    db_save(db)
    return {"ok": True, "pid": proc.pid}


def stop_bot(bot_id: str, manual: bool = True) -> Dict[str, Any]:
    with _LOCK:
        info = RUNNING.get(bot_id)
    if info:
        info["manual_stop"] = manual
        proc = info["proc"]
        try:
            if os.name == "posix":
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    proc.terminate()
            else:
                proc.terminate()
            try:
                proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                if os.name == "posix":
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        proc.kill()
                else:
                    proc.kill()
        except Exception:
            pass
        with _LOCK:
            RUNNING.pop(bot_id, None)

    db = db_load()
    b = db["bots"].get(bot_id)
    if b:
        b["status"] = "stopped"
        b["pid"] = None
        db_save(db)
    return {"ok": True}


def bot_logs(bot_id: str, n: int = 120) -> List[str]:
    with _LOCK:
        info = RUNNING.get(bot_id)
        if info:
            return list(info["log"][-n:])
    db = db_load()
    b = db["bots"].get(bot_id)
    if b and b.get("last_error"):
        return (b["last_error"] or "").splitlines()
    return []


def is_running(bot_id: str) -> bool:
    with _LOCK:
        info = RUNNING.get(bot_id)
        if not info:
            return False
        if info["proc"].poll() is not None:
            return False
        return True


# ═══════════════════════════════════════════════════════════════════
#  UPLOAD / CREATE
# ═══════════════════════════════════════════════════════════════════

def _new_bot_id() -> str:
    return secrets.token_hex(4)


def create_bot_from_upload(owner: str, name: str, file_storage) -> Dict[str, Any]:
    if user_bot_count(owner) >= user_max_bots(owner):
        return {"ok": False, "error": "Bot slot limit reached. Upgrade plan."}

    bot_id = _new_bot_id()
    bot_dir = BOTS_DIR / bot_id
    bot_dir.mkdir(parents=True)

    filename = secure_filename(file_storage.filename or "bot.py")
    raw = UPLOADS_DIR / f"{bot_id}_{filename}"
    file_storage.save(raw)

    try:
        if filename.lower().endswith(".zip"):
            with zipfile.ZipFile(raw, "r") as zf:
                zf.extractall(bot_dir)
            # if single top-level folder, flatten
            kids = [c for c in bot_dir.iterdir() if c.name != "__MACOSX"]
            if len(kids) == 1 and kids[0].is_dir():
                for item in kids[0].iterdir():
                    shutil.move(str(item), str(bot_dir / item.name))
                shutil.rmtree(kids[0], ignore_errors=True)
        else:
            shutil.copy(raw, bot_dir / filename)
            # rename to bot.py if only one py and not main/bot
            entry = _find_entry(bot_dir)
            if not entry and filename.endswith(".py"):
                (bot_dir / filename).rename(bot_dir / "bot.py")
    except Exception as e:
        shutil.rmtree(bot_dir, ignore_errors=True)
        return {"ok": False, "error": f"Extract failed: {e}"}
    finally:
        try:
            raw.unlink(missing_ok=True)
        except Exception:
            pass

    if not _find_entry(bot_dir):
        shutil.rmtree(bot_dir, ignore_errors=True)
        return {"ok": False, "error": "No .py entry file found (need main.py or bot.py)"}

    db = db_load()
    db["bots"][bot_id] = {
        "id": bot_id,
        "name": name or filename,
        "owner": owner,
        "dir": str(bot_dir),
        "status": "stopped",
        "created": _now(),
        "last_started": None,
        "last_error": "",
        "last_exit_code": None,
        "pid": None,
        "env": {},
        "auto_restart": True,
    }
    db_save(db)
    return {"ok": True, "bot_id": bot_id}


def delete_bot(bot_id: str) -> None:
    stop_bot(bot_id, manual=True)
    db = db_load()
    b = db["bots"].pop(bot_id, None)
    db_save(db)
    if b:
        shutil.rmtree(b.get("dir", ""), ignore_errors=True)


# ═══════════════════════════════════════════════════════════════════
#  ROUTES — AUTH
# ═══════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    if session.get("user"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        u = get_user(username)
        if u and not u.get("banned") and check_password_hash(u["password"], password):
            session["user"] = username
            session["role"] = u.get("role", "user")
            flash("Welcome back!", "ok")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = (request.form.get("username") or "").strip().lower()
        password = request.form.get("password") or ""
        if not re.match(r"^[a-z0-9_]{3,20}$", username):
            flash("Username: 3-20 chars, a-z 0-9 _ only.", "error")
            return render_template("register.html")
        if len(password) < 6:
            flash("Password min 6 characters.", "error")
            return render_template("register.html")
        data = users_load()
        if username in data["users"]:
            flash("Username already taken.", "error")
            return render_template("register.html")
        data["users"][username] = {
            "password": generate_password_hash(password),
            "role": "user",
            "plan": "free",
            "max_bots": 2,
            "created": _now(),
            "banned": False,
        }
        users_save(data)
        session["user"] = username
        session["role"] = "user"
        flash("Account created!", "ok")
        return redirect(url_for("dashboard"))
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ═══════════════════════════════════════════════════════════════════
#  ROUTES — DASHBOARD
# ═══════════════════════════════════════════════════════════════════

@app.route("/dashboard")
@login_required
def dashboard():
    user = session["user"]
    db = db_load()
    if session.get("role") == "admin":
        bots = list(db["bots"].values())
    else:
        bots = [b for b in db["bots"].values() if b.get("owner") == user]
    for b in bots:
        b["running"] = is_running(b["id"])
        if b["running"]:
            b["status"] = "running"
    stats = {
        "total": len(bots),
        "running": sum(1 for b in bots if b.get("running")),
        "slots": f"{user_bot_count(user)} / {user_max_bots(user)}",
    }
    return render_template("dashboard.html", bots=bots, stats=stats, user=user)


@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip() or "My Bot"
        f = request.files.get("file")
        if not f or not f.filename:
            flash("Select a .py or .zip file.", "error")
            return redirect(url_for("upload"))
        ext = f.filename.rsplit(".", 1)[-1].lower()
        if ext not in ("py", "zip"):
            flash("Only .py or .zip allowed.", "error")
            return redirect(url_for("upload"))
        res = create_bot_from_upload(session["user"], name, f)
        if res.get("ok"):
            flash(f"Bot uploaded: {res['bot_id']}", "ok")
            return redirect(url_for("bot_view", bot_id=res["bot_id"]))
        flash(res.get("error", "Upload failed"), "error")
    return render_template("upload.html", max_mb=MAX_UPLOAD_MB)


@app.route("/bot/<bot_id>")
@login_required
def bot_view(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b:
        flash("Bot not found.", "error")
        return redirect(url_for("dashboard"))
    if b["owner"] != session["user"] and session.get("role") != "admin":
        flash("Access denied.", "error")
        return redirect(url_for("dashboard"))
    b["running"] = is_running(bot_id)
    logs = bot_logs(bot_id)
    return render_template("bot.html", bot=b, logs=logs)


@app.route("/bot/<bot_id>/start", methods=["POST"])
@login_required
def bot_start(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b or (b["owner"] != session["user"] and session.get("role") != "admin"):
        return jsonify({"ok": False, "error": "Denied"}), 403
    res = start_bot(bot_id)
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify(res)
    flash("Started" if res.get("ok") else res.get("error", "Failed"), "ok" if res.get("ok") else "error")
    return redirect(url_for("bot_view", bot_id=bot_id))


@app.route("/bot/<bot_id>/stop", methods=["POST"])
@login_required
def bot_stop(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b or (b["owner"] != session["user"] and session.get("role") != "admin"):
        return jsonify({"ok": False, "error": "Denied"}), 403
    res = stop_bot(bot_id)
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify(res)
    flash("Stopped", "ok")
    return redirect(url_for("bot_view", bot_id=bot_id))


@app.route("/bot/<bot_id>/restart", methods=["POST"])
@login_required
def bot_restart(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b or (b["owner"] != session["user"] and session.get("role") != "admin"):
        return jsonify({"ok": False, "error": "Denied"}), 403
    stop_bot(bot_id)
    time.sleep(1)
    res = start_bot(bot_id)
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify(res)
    flash("Restarted" if res.get("ok") else res.get("error", "Failed"), "ok" if res.get("ok") else "error")
    return redirect(url_for("bot_view", bot_id=bot_id))


@app.route("/bot/<bot_id>/delete", methods=["POST"])
@login_required
def bot_delete(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b or (b["owner"] != session["user"] and session.get("role") != "admin"):
        flash("Denied", "error")
        return redirect(url_for("dashboard"))
    delete_bot(bot_id)
    flash("Bot deleted.", "ok")
    return redirect(url_for("dashboard"))


@app.route("/bot/<bot_id>/logs")
@login_required
def bot_logs_api(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b or (b["owner"] != session["user"] and session.get("role") != "admin"):
        return jsonify({"ok": False}), 403
    return jsonify({"ok": True, "logs": bot_logs(bot_id), "running": is_running(bot_id)})


@app.route("/bot/<bot_id>/env", methods=["GET", "POST"])
@login_required
def bot_env(bot_id: str):
    db = db_load()
    b = db["bots"].get(bot_id)
    if not b or (b["owner"] != session["user"] and session.get("role") != "admin"):
        flash("Denied", "error")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        # KEY=VALUE lines
        raw = request.form.get("env_text") or ""
        env = {}
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
        b["env"] = env
        db_save(db)
        flash("Environment saved. Restart bot to apply.", "ok")
        return redirect(url_for("bot_view", bot_id=bot_id))
    env_text = "\n".join(f"{k}={v}" for k, v in (b.get("env") or {}).items())
    return render_template("env.html", bot=b, env_text=env_text)


# ═══════════════════════════════════════════════════════════════════
#  ADMIN
# ═══════════════════════════════════════════════════════════════════

@app.route("/admin")
@admin_required
def admin():
    users = users_load()["users"]
    db = db_load()
    bots = list(db["bots"].values())
    for b in bots:
        b["running"] = is_running(b["id"])
    return render_template(
        "admin.html",
        users=users,
        bots=bots,
        running=sum(1 for b in bots if b.get("running")),
    )


@app.route("/admin/user/<username>/plan", methods=["POST"])
@admin_required
def admin_set_plan(username: str):
    data = users_load()
    u = data["users"].get(username)
    if not u:
        flash("User not found", "error")
        return redirect(url_for("admin"))
    plan = request.form.get("plan", "free")
    limits = {"free": 2, "starter": 5, "pro": 15, "unlimited": 9999}
    u["plan"] = plan
    u["max_bots"] = limits.get(plan, 2)
    users_save(data)
    flash(f"Plan updated for {username}", "ok")
    return redirect(url_for("admin"))


@app.route("/admin/user/<username>/ban", methods=["POST"])
@admin_required
def admin_ban(username: str):
    if username == session["user"]:
        flash("Cannot ban yourself", "error")
        return redirect(url_for("admin"))
    data = users_load()
    u = data["users"].get(username)
    if u:
        u["banned"] = not u.get("banned", False)
        users_save(data)
        flash(f"{'Banned' if u['banned'] else 'Unbanned'} {username}", "ok")
    return redirect(url_for("admin"))


# ═══════════════════════════════════════════════════════════════════
#  API status
# ═══════════════════════════════════════════════════════════════════

@app.route("/api/status")
def api_status():
    return jsonify({
        "ok": True,
        "bots_running": sum(1 for bid in list(RUNNING) if is_running(bid)),
        "time": _now(),
    })


# ═══════════════════════════════════════════════════════════════════

def main():
    users_load()  # ensure admin exists
    print(f"Telegram Bot Hosting Panel")
    print(f"  http://{HOST}:{PORT}")
    print(f"  Admin: {ADMIN_USER} / {ADMIN_PASS}")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)


if __name__ == "__main__":
    main()
