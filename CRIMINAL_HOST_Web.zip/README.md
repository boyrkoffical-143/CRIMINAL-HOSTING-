# CRIMINAL HOST — Telegram Bot Hosting Panel (Web)

Premium web panel to upload, run, stop and manage Telegram bots.

**Owner:** [@CRIMINAL_HUBBYx](https://t.me/CRIMINAL_HUBBYx)

## Features
- Register / Login (password)
- Upload `.py` or `.zip` bots
- Start / Stop / Restart / Delete
- Live logs
- Environment variables (`BOT_TOKEN=...`)
- Auto-install packages from requirements + import scan
- Auto-fix `ModuleNotFoundError` → install + restart
- Admin panel (users, plans, ban, all bots)
- Plans: Free 2 · Starter 5 · Pro 15 · Unlimited

## Default Admin
- User: `admin`
- Pass: `admin123`  ← **change after first login**

Env override:
```
ADMIN_USER=admin
ADMIN_PASS=your_strong_password
SECRET_KEY=random_long_string
PORT=8080
```

## Run Local
```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:8080

## Deploy (recommended)

### Railway
1. New project → Deploy from folder/GitHub
2. Set env: `ADMIN_USER`, `ADMIN_PASS`, `SECRET_KEY`
3. Start command already in `railway.json`

### Render
1. New Web Service → connect repo
2. Uses `render.yaml`

### VPS
```bash
pip install -r requirements.txt
gunicorn app:app -b 0.0.0.0:8080 --workers 1 --threads 8
```

## ⚠ Vercel
Vercel is **serverless** — long-running bot processes **cannot** stay alive there.
Use **Railway / Render / VPS** for real bot hosting.
`vercel.json` is only for testing the UI shell.

## How users host a bot
1. Register → Login
2. Upload bot file
3. Environment → add `BOT_TOKEN=...`
4. Start
