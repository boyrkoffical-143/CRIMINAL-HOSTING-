/* CRIMINAL HOST — client helpers */
document.addEventListener('DOMContentLoaded', () => {
  // Auto-hide flashes
  document.querySelectorAll('.flash').forEach(el => {
    setTimeout(() => {
      el.style.transition = 'opacity 0.4s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 400);
    }, 4500);
  });
});
